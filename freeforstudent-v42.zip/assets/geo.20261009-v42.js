(()=>{
 const switcher=document.getElementById('regionSwitcher');
 switcher?.addEventListener('change',()=>{if(switcher.value)location.href=switcher.value});
 const announcement=document.getElementById('announcement'),dismiss=document.getElementById('dismissAnnouncement'),announcementKey='ffs:announcement:2026-10-08';
 try{if(localStorage.getItem(announcementKey)==='dismissed')announcement?.classList.add('is-dismissed')}catch(e){}
 dismiss?.addEventListener('click',()=>{announcement?.classList.add('is-dismissed');try{localStorage.setItem(announcementKey,'dismissed')}catch(e){}});
 const categoryNav=document.getElementById('categoryNav'),categoryButtons=[...document.querySelectorAll('[data-category-scroll]')];
 const updateCategoryButtons=()=>{if(!categoryNav)return;const max=categoryNav.scrollWidth-categoryNav.clientWidth;categoryButtons.forEach(b=>{b.disabled=b.dataset.categoryScroll==='left'?categoryNav.scrollLeft<4:categoryNav.scrollLeft>max-4})};
 categoryButtons.forEach(b=>b.addEventListener('click',()=>categoryNav?.scrollBy({left:(b.dataset.categoryScroll==='left'?-1:1)*240,behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'auto':'smooth'})));
 categoryNav?.addEventListener('scroll',updateCategoryButtons,{passive:true});addEventListener('resize',updateCategoryButtons,{passive:true});updateCategoryButtons();
 const options=[...document.querySelectorAll('[data-feature-option]')],panel=document.getElementById('featurePanel');
 const feature={brand:document.getElementById('featureBrand'),title:document.getElementById('featureTitle'),desc:document.getElementById('featureDesc'),region:document.getElementById('featureRegion'),logo:document.getElementById('featureLogo'),cta:document.getElementById('featureCta')};
 options.forEach(option=>option.addEventListener('click',event=>{if(!panel)return;event.preventDefault();options.forEach(x=>{const on=x===option;x.classList.toggle('on',on);x.setAttribute('aria-selected',String(on))});feature.brand.textContent=option.dataset.brand;feature.title.textContent=option.dataset.title;feature.desc.textContent=option.dataset.desc;feature.region.textContent=option.dataset.region;feature.logo.src=option.dataset.logo;feature.logo.alt=option.dataset.brand+' logo';feature.cta.href=option.dataset.url;panel.style.setProperty('--feature-c1',option.dataset.c1);panel.style.setProperty('--feature-c2',option.dataset.c2)}));
})();

;(()=>{
 const panel=document.getElementById('featurePanel'),picture=panel?.querySelector('.feature-media'),options=[...document.querySelectorAll('[data-feature-option][data-image-theme]')];
 if(!picture||!options.length)return;
 const update=theme=>{
  const base=`/assets/img/${theme}-v1`;
  const sources=picture.querySelectorAll('source');
  if(sources[0])sources[0].srcset=`${base}-480.avif 480w, ${base}-800.avif 800w, ${base}-1200.avif 1200w`;
  if(sources[1])sources[1].srcset=`${base}-480.webp 480w, ${base}-800.webp 800w, ${base}-1200.webp 1200w`;
  const img=picture.querySelector('img');if(img){img.src=`${base}-1200.jpg`;img.srcset=`${base}-480.jpg 480w, ${base}-800.jpg 800w, ${base}-1200.jpg 1200w`;img.alt=({'education':'Notebooks, textbooks and study materials on a coloured background','design-creative':'Drawing tablet with stylus and colour swatches','devices-hardware':'Laptop, tablet and headphones arranged on a coloured background','health-wellbeing':'Calm wellbeing corner with yoga mat, plant and tea','learning-courses':'Laptop showing an online course in a warm-lit study space','reading-news':'E-reader, books and coffee on a coloured background','food-delivery':'Unbranded food-delivery meal arranged on a colourful table','streaming-night':'Headphones, popcorn and a remote in a purple-lit room'})[theme]||'Unbranded laptop, notebook and headphones on a student study desk'};
 };
 options.forEach(option=>option.addEventListener('click',()=>update(option.dataset.imageTheme)));
 update(document.querySelector('[data-feature-option][aria-selected="true"]')?.dataset.imageTheme||options[0].dataset.imageTheme);
 const cards=[...document.querySelectorAll('.card.photo-card')];
 const reveal=card=>card.classList.add('photo-loaded');
 if(!('IntersectionObserver' in window))cards.forEach(reveal);
 else{const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){reveal(entry.target);observer.unobserve(entry.target)}}),{rootMargin:'280px 0px'});cards.forEach(card=>observer.observe(card))}
})();
