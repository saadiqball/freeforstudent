# Image licence ledger
All nine photographic themes below were generated for FreeForStudent (owner-held originals, 2026-10-08/09). No competitor, stock or brand-licensed photography is used. Brand wordmarks/logos appear only as nominative references on listing cards.
| file | source | licence | added | used |
|---|---|---|---|---|
| study-desk-v1-* | owner-generated | owner-held | 2026-10-08 | hero, software/tools + developer cards, guides |
| food-delivery-v1-* | owner-generated | owner-held | 2026-10-08 | shopping/food cards + category strip |
| streaming-night-v1-* | owner-generated | owner-held | 2026-10-08 | streaming/music cards + category strip, renewals guide |
| education-v1-* | owner-generated | owner-held | 2026-10-09 | education category strip, verification guide, learning cards |
| design-creative-v1-* | owner-generated | owner-held | 2026-10-09 | design cards + category strip, portfolio guide |
| devices-hardware-v1-* | owner-generated | owner-held | 2026-10-09 | devices cards + category strip |
| health-wellbeing-v1-* | owner-generated | owner-held | 2026-10-09 | health cards + category strip |
| learning-courses-v1-* | owner-generated | owner-held | 2026-10-09 | learning cards + category strip |
| reading-news-v1-* | owner-generated | owner-held | 2026-10-09 | reading/news cards + category strip |
