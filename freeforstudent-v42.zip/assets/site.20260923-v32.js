
(()=>{
  const root=document.documentElement;
  let theme='light';
  try{theme=localStorage.getItem('sp:theme')||((matchMedia('(prefers-color-scheme:dark)').matches)?'dark':'light')}catch(e){}
  root.dataset.theme=theme;
  const toast=(msg)=>{const t=document.getElementById('toast');if(!t)return;t.textContent=msg;t.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove('on'),2200)};
  document.getElementById('themeBtn')?.addEventListener('click',()=>{theme=theme==='light'?'dark':'light';root.dataset.theme=theme;try{localStorage.setItem('sp:theme',theme)}catch(e){};toast(theme==='dark'?'Dark mode on':'Light mode on')});
  const burger=document.getElementById('burger'),menu=document.getElementById('mobileMenu');
  const closeMenu=()=>{if(menu)menu.style.display='none';burger?.setAttribute('aria-expanded','false')};
  burger?.addEventListener('click',()=>{const open=menu?.style.display==='block';if(menu)menu.style.display=open?'none':'block';burger.setAttribute('aria-expanded',String(!open))});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&menu?.style.display==='block'){closeMenu();burger?.focus()}});
  menu?.querySelectorAll('a').forEach(a=>a.addEventListener('click',closeMenu));
  const top=document.getElementById('top');
  addEventListener('scroll',()=>top?.classList.toggle('on',scrollY>600),{passive:true});
  top?.addEventListener('click',()=>scrollTo({top:0,behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'auto':'smooth'}));
  const yr=document.getElementById('yr');if(yr)yr.textContent=new Date().getFullYear();
  if(document.getElementById('savedBtn')&&!document.getElementById('grid'))document.getElementById('savedBtn').addEventListener('click',()=>location.href='/?saved=1#browse');
  window.ffsToast=toast;
})();

;(()=>{
  document.querySelectorAll('form[data-netlify]').forEach(f=>{
    f.addEventListener('submit',async e=>{
      e.preventDefault();
      const btn=f.querySelector('[type="submit"]'),old=btn?btn.textContent:'';
      const err=f.querySelector('.form-error');if(err)err.hidden=true;
      if(btn){btn.disabled=true;btn.textContent='Sending…'}
      try{
        const r=await fetch(f.getAttribute('action')||'/',{method:'POST',body:new FormData(f),headers:{'Accept':'text/html'}});
        if(r.ok||r.redirected){location.assign(f.getAttribute('action')||'/thank-you');return}
        throw new Error('bad status');
      }catch(err){
        if(btn){btn.disabled=false;btn.textContent=old}
        if(err)err.hidden=false;
        window.ffsToast?.('Sending failed — please retry or email us');
      }
    });
  });
})();
